﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appointment
{
    public class CreateAppointment
    {
        DateTime date;

        //define delegate
        public delegate void AppointmentSenderEventHandler(object source, EventArgs args);

        //define event
        public event AppointmentSenderEventHandler SendAppointment;

        //raise an event
        protected virtual void OnSendAppointment()
        {
            SendAppointment?.Invoke(this, EventArgs.Empty);

        }
        public void Appointment()
        {
            date = DateTime.Now;
            Console.WriteLine($"Appointment is on {date}");
            OnSendAppointment();
        }
    }
}

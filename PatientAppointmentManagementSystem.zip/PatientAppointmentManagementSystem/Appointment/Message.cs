﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appointment
{
    public class Message
    {
       public void OnSendAppointment(Object source, EventArgs args)
        {
            Console.WriteLine("Message sent to patient's phone number and doctor phone number");
        }
    }
}

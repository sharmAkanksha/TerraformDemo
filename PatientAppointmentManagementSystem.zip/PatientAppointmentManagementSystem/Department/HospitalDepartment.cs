﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Department
{
    public class HospitalDepartment
    {
       public virtual void Doctor()
        {
            Console.WriteLine("Welcome to ABC Hospital");
        }
    }
}

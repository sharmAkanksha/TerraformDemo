﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Department
{
    public class CardiologyDepartment:HospitalDepartment
    {
        string doctorName;
        public override void Doctor()
        {
            base.Doctor();
            doctorName = "John";
            Console.WriteLine($"Doctor name is {doctorName}");
        }
    }
}

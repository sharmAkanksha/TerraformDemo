﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Department
{
    public class OncologyDepartment: HospitalDepartment
    {
        string doctorName;

        public override void Doctor()
        {
            base.Doctor();
            doctorName = "Robert";
            Console.WriteLine($"Doctor name is {doctorName}");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientAppointmentManagementSystem
{
    class Registration
    {
        #region private data members
        private string _id;
        private string _name;
        private string _email;
        private string _phoneNumber;
        #endregion

        #region constructor

        public Registration(string name, string email, string phoneNumber)
        {
            System.Random _randomId = new Random();
            this._id = $"name{_randomId.Next()}";
            this._name = name;
            this._email = email;
            this._phoneNumber = phoneNumber;
        }
        #endregion
    }
}

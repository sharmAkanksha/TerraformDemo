﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Department;
using Appointment;

namespace PatientAppointmentManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Registration patientOne = new Registration("Joy", "Joy@gmail.com", "1234");
            var department = new CardiologyDepartment();
            var createAppointment = new CreateAppointment();
            var mailService = new MailService();
            var messageService = new Message();

            department.Doctor();

            createAppointment.SendAppointment += mailService.OnSendAppointment;
            createAppointment.SendAppointment += messageService.OnSendAppointment;

            createAppointment.Appointment();
            Console.ReadLine();
        }
    }
}
